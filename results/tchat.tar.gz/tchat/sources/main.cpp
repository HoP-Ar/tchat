#include "chat.hpp"

int main(int argc,char** argv){
	Opts opts(argc, argv);
	opts.run();
	return 0;
}

